import Nav from "@/components/nav/nav";
import Newsletter from "@/components/newsletter/Newsletter";

export default function Reviews() {
  return (
    <div>
      <Nav />
      <Newsletter />
    </div>
  );
}
